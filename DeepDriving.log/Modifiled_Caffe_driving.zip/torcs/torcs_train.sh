#!/usr/bin/env sh

../build/tools/caffe train \
    --solver=pre_trained/driving_solver_1F.prototxt \
    #--gpu=1
